Start game by running hangman.py from command line.

Good luck!